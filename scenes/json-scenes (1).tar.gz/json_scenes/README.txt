Here are the sample scenes that are included with the project.
Feel free to look them over and become familiar with their format
(if you dont do it sooner, you will have to do it later when you make your artifact).  

The scenes in the simple\ directory are ones that you should use for basic tests, and
their correct results can be viewed on the web page. The scenes in the polymesh\
directory include trimesh's. Implementing trimesh intersections is a bell this
quarter, but some of these scenes will still look interesting even without the
trimesh implementation.

scene.ray is a simple file that you can use as the starting point for your own scenes.
It already has a good camera and lighting setup, so you can just delete the sphere and
add your own test objects.